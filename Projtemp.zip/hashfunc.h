unsigned long hash1(unsigned char *str);
unsigned long hash2(unsigned char *str);
unsigned long hash3(unsigned char *str);
unsigned long hash4( const char * str, int len,unsigned int seed );
unsigned long hash5(unsigned char *str, unsigned int i);
unsigned long hash6(unsigned char *str, unsigned int i);
unsigned long hash7(unsigned char *str, unsigned int i);
unsigned long hash8(unsigned char *str, unsigned int i);
